<div class="container-fluid p-3 bg-dark text-white text-center">
    <small class="text-muted" style="margin:0;padding:0;">Copyright&#169;2020</small>
</div>